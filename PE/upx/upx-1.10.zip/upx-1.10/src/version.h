#define UPX_VERSION             0x011000        /* 01.10.00 */
#define UPX_VERSION_STRING      "1.10"
#define UPX_VERSION_DATE        "Dec 20th 2000"
