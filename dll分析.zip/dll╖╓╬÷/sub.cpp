//sub.cpp
#include<windows.h>
#include<stdio.h>

extern "C" int __declspec(dllexport)  __stdcall sub(int x, int y);

int __stdcall sub(int x, int y)
{
	return x - y;
}
