#include<iostream>
using namespace std;
extern "C" _declspec(dllimport) int sum(int a,int b);

int main(int argc,char *argv[])
{
	int a;
	a = sum(8,10);
	cout << "a=" <<a <<endl;
	return 0;
}